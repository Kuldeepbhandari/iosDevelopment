//
//  ValidationObject.swift
//  Employee Record System
//
//  Created by appinventiv on 21/02/20.
//  Copyright © 2020 appinventiv. All rights reserved.
//

import Foundation

class ValidationObject:NSObject{
    
    public static let validation = Validatoin()
    
    
}
